from django.db import models

class projectname(models.Model):
    pname = models.CharField(max_length=20)
    shift = models.CharField(max_length=20)


class storeupdates(models.Model):
    projectname = models.CharField(max_length=20)
    projectupdates = models.CharField(max_length=500)
    freeresource = models.CharField(max_length=10)
    date = models.CharField(max_length=10)
    updatedby = models.CharField(max_length=20)

