from django.shortcuts import render, redirect
from .models import *
from datetime import *


def showupdates(request):
    date2 = date.today()
   # yesterday = date2 - timedelta(days=1)
    obj1 = projectname.objects.raw(
        'select displayupdates_projectname.id,displayupdates_projectname.pname,displayupdates_storeupdates.projectupdates,displayupdates_storeupdates.freeresource FROM displayupdates_projectname Left join displayupdates_storeupdates ON displayupdates_projectname.pname=displayupdates_storeupdates.projectname AND displayupdates_storeupdates.date =%s',
        params=[date2])
    return render(request, 'template.html', {'key': obj1})


def yest(request):
    date2 = date.today()
    ye = date2 - timedelta(days=1)
    obj1 = projectname.objects.raw(
        'select displayupdates_projectname.id,displayupdates_projectname.pname,displayupdates_storeupdates.projectupdates,displayupdates_storeupdates.freeresource FROM displayupdates_projectname Left join displayupdates_storeupdates ON displayupdates_projectname.pname=displayupdates_storeupdates.projectname AND displayupdates_storeupdates.date =%s',
        params=[ye])
    return render(request, 'yesterday.html', {'key': obj1})



def addupdates(request, pname):
    return render(request, 'addupdates.html', {'key1': pname})


def insertdata(request, key):
    pro = key
    date1 = date.today()
    updates = request.POST["addupdates"]
    res = request.POST["freeresources"]
    objd = storeupdates(projectname=pro, projectupdates=updates, freeresource=res, date=date1)
    objd.save()
    #return render(request, 'template.html')
    return redirect('/')

########

def yestupdates(request, pname):
    date2 = date.today()
    yesterday = date2 - timedelta(days=1)

    obj1 = storeupdates.objects.filter(projectname=pname, date=yesterday)

    for idv in obj1:
        oldid = idv.id

    return addupdates(request, pname, oldid)
