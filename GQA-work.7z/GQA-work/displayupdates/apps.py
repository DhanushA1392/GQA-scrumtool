from django.apps import AppConfig


class DisplayupdatesConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'displayupdates'
